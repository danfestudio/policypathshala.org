﻿<!doctype html>
<html lang="zxx">
    <?php include 'head.php';?>	
    <body>
		<!-- Start Preloader Area -->
		<div class="preloader">
			<div class="lds-ripple">
				<div class="pl-flip-1 pl-flip-2"></div>
			</div>
		</div>
		<!-- End Preloader Area -->
		
		<!-- Start Header Area -->
		<?php include 'header.php';?>	
		<!-- End Header Area -->

		<!-- Search Modal -->
		<div class="modal fade search-modal-area" id="exampleModalsrc">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<button type="button" data-bs-dismiss="modal" class="closer-btn">
						<i class="ri-close-line"></i>
					</button>

					<div class="modal-body">
						<form class="search-box">
							<div class="search-input">
								<input type="text" name="Search" placeholder="Search for..." class="form-control">

								<button type="submit" class="search-btn">
									<i class="ri-search-line"></i>
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Search Modal -->

		<!-- Start Page Title Area -->
		<div class="page-title-area bg-1">
			<div class="container">
				<div class="page-title-content">
					<h2>Policy Dialouge</h2>

					<ul>
						<li>
							<a href="index.php">
								Home 
							</a>
						</li>

						<li class="active">Policy Dialouge</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End Page Title Area -->

		<!-- Start Events Area -->
		<section class="cart-area ptb-100">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						
						
							
								<table>
									<thead>
										<tr>
											<th width="8%"></th>
											
											<th width="28%"></th>
											<th width="50%"></th>
											<th width="2%"></th>
											<th width="12%"></th>
										</tr>
									</thead>
																			
									<tbody>
									<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>“Procurement
													Reform in Health
													Sector”</h6></a>
												</td>

											<td class="">
																					<p>
																					A Public Policy Dialogue on “Procurement Reform in
												Health Sector” was organized on 1 August, 20019 at
												Hotel Shangrila, Kathmandu. The dialogue was co-
												hosted by Public Policy Pathshala and The Asia
												Foundation to discuss on the Public Procurement Act
												and its implementation challenges in procurement of
												medicines and equipment’s. The dialogue was
												attended by health procurement experts, members of
												parliament, experts on local governance, donor
												representatives, civil society members, and other
												stakeholders.
																					</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/7.jpg" target_blank>
													<img src="assets/images/cb/activities/7.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>	Public Policy Dialogue
													on Newborn Health in
													Province 2</h6></a>
												</td>

											<td class="">
																					<p>	A public policy dialogue at provincial level was
													organized in Janakpur on 6 March, 2019 to share and
													discuss on the findings from series of discussion with
													the local governments at province 2 on newborn health. Principal Secretary of Province No. 2
													government, Secretary for Social Development
													Ministry, Director from Province Health Directorate,
													representatives from local governments,
													representatives from development partners and health
													sector experts participated in the program.</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/5.jpg" target_blank>
													<img src="assets/images/cb/activities/5.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2018</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Local Health Governance in Gandaki Province</h6></a>
												</td>

											<td class="">
																					<p>
																					A multi-sector policy dialogue on issues of local health governance was organized in Pokhara on March 2018. Officials from over 40 local governments, Regional Director for Health (rechristened Provincial Health Directorate), district level health officials (rechristened Provincial health Office) and health sector experts actively participated in the province. The event focused on the challenges of federal transition in health sector.</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/16.jpg" target_blank>
													<img src="assets/images/cb/activities/16.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2018</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>		“Pertinent Issues and Challenges of Public Health</h6></a>
												</td>

											<td class="">
																					<p>
																					Following the endorsement of the Public Health Service Act, Public Policy Dialogue on “Pertinent Issues and Challenges of Public Health”- co-hosted by PPP and DFAT-TAF- was organized on September 21, 2018.
																					</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/9.jpg" target_blank>
													<img src="assets/images/cb/activities/9.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										
										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2016</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Public Finance</h6></a>
												</td>

											<td class="">
																					<p>
																					A glimpse of the Pathshala debate

												Public Finance expert Jagdish Bhattarai was the
												presenter at the event, which was organized in the first
												week of May, focusing on the budget of the PPP
												debate. Gagan Thapa and economist Dr. Bishwo
												Poudel had a discussion.</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/12.jpg" target_blank>
													<img src="assets/images/cb/activities/12.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>
										
								
								
								
									
								
								
								
									
								
								
									
									
									
									
									
									
									</tbody>
								</table>
							</div>
						</form>
		
						
					</div>

					
				</div>
			</div>
		</section>
		<!-- End Events Area -->

		<?php include 'footer.php';?>
		
		<!-- Start Go Top Area -->
		<div class="go-top">
			<i class="ri-arrow-up-s-fill"></i>
			<i class="ri-arrow-up-s-fill"></i>
		</div>
		<!-- End Go Top Area -->

        <!-- Jquery Min JS -->
        <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script> 
        <!-- Bootstrap Bundle Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Meanmenu Min JS -->
		<script src="assets/js/meanmenu.min.js"></script>
		<!-- Owl Carousel Min JS -->
		<script src="assets/js/owl.carousel.min.js"></script>
		<!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
		<!-- Appear Min JS -->
        <script src="assets/js/appear.min.js"></script>
		<!-- Odometer Min JS -->
        <script src="assets/js/odometer.min.js"></script>
		<!-- Jarallax Min JS -->
        <script src="assets/js/jarallax.min.js"></script>
		<!-- Bootstrap Datepicker Min JS -->
        <script src="assets/js/bootstrap-datepicker.min.js"></script>
		<!-- Magnific Popup Min JS -->
        <script src="assets/js/magnific-popup.min.js"></script>
		<!-- Form Validator Min JS -->
		<script src="assets/js/form-validator.min.js"></script>
		<!-- Contact JS -->
		<script src="assets/js/contact-form-script.js"></script>
		<!-- Ajaxchimp Min JS -->
		<script src="assets/js/ajaxchimp.min.js"></script>
        <!-- Custom JS -->
		<script src="assets/js/custom.js"></script>
    </body>
</html>