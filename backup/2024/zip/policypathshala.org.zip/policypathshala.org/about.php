﻿<!doctype html>
<html lang="zxx">

     <?php include 'head.php';?>	

    <body>
		<!-- Start Preloader Area -->
		<div class="preloader">
			<div class="lds-ripple">
				<div class="pl-flip-1 pl-flip-2"></div>
			</div>
		</div>
		<!-- End Preloader Area -->
		
		 <?php include 'header.php';?>

		<!-- Search Modal -->
		<div class="modal fade search-modal-area" id="exampleModalsrc">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<button type="button" data-bs-dismiss="modal" class="closer-btn">
						<i class="ri-close-line"></i>
					</button>

					<div class="modal-body">
						<form class="search-box">
							<div class="search-input">
								<input type="text" name="Search" placeholder="Search for..." class="form-control">

								<button type="submit" class="search-btn">
									<i class="ri-search-line"></i>
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Search Modal -->

		<!-- Start Page Title Area -->
		<div class="page-title-area bg-1">
			<div class="container">
				<div class="page-title-content">
					<h2>About</h2>

					<ul>
						<li>
							<a href="index.php">
								Home 
							</a>
						</li>

						<li class="active">About Public Policy Patshala</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End Page Title Area -->

		<!-- Stat About Area -->
		<section class="about-area ptb-100">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-xl-6">
						<div class="about-img-two mr-15">
							<img src="assets/images/cb/about-img-2.jpg" alt="Image">

							<div class="about-shape">
								<img src="assets/images/about-shape.png" alt="Image">
							</div>
						</div>
					</div>

					<div class="col-xl-6">
						<div class="about-content ml-15">
							<span>About Public Policy Pathshala (PPP)</span>
							
							<h3>Public Policy Pathshala is a research and policy institute.</h3><p> Established in 2010 AD, Public Policy Pathshala (PPP) is a reputable research and policy institute driven by a group of dynamic young professionals. The primary goal of PPP is to actively contribute to national policy processes through comprehensive policy research, engaging policy dialogues, effective advocacy, knowledge management, and evidence generation. A distinctive strength of PPP lies in its extensive network, allowing it to harness the expertise and talents of a diverse range of professionals both within and beyond the borders of Nepal. <br>
PPP has fostered close collaborations with governmental bodies at all levels, including the federal, provincial, and local governments. This strategic partnership enables PPP to provide invaluable assistance and support in various areas, such as conducting rigorous policy research, facilitating inclusive policy discussions, enhancing capacity-building initiatives, and actively contributing to the formulation of impactful laws and policies. By fostering effective partnerships and actively engaging with stakeholders, PPP strives to foster evidence-based decision-making processes and drive positive policy reforms for the betterment of Nepal and its people. 
Together, let's shape a future of evidence-based policies that drive positive change and foster sustainable development in Nepal.

</p>
							<a href="activities.php" class="default-btn">
								Our activies
								<i class="ri-arrow-right-line"></i>
							</a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End About Area -->

		<section class="studys-area pb-70">
			<div class="container">
				
				<div class="row justify-content-center">
					<div class="col-lg-4 col-md-6">
						<div class="single-study study-f3f3f4">
							<i class="flaticon-contract"></i>
							<h3>
								<a href="study-online.html">Vision</a>
							</h3>
							<p>Public Policy Pathshala aims at the creation of an equitable, just and prosperous society enriched by the principles of democracy.</p>
							
							
						</div>
					</div>

					<div class="col-lg-4 col-md-6">
						<div class="single-study study-f3f3f4">
							<i class="flaticon-contract"></i>
							<h3>
								<a href="study-online.html">Mission</a>
							</h3>
							<p>To develop and disseminate knowledge through research, publication, campaign and dialogue among key stakeholders in Society.</p>
							
						</div>
					</div>

					<div class="col-lg-4 col-md-6">
						<div class="single-study study-f3f3f4">
							<i class="flaticon-contract"></i>
							<h3>
								<a href="study-online.html">Values</a>
							</h3>
							<p>We believe in Rules of Law, Individual Freedom, Democracy, Good Governance, Transparency, Social Justice and Non-violence.</p>
							
							
						</div>
					</div>
				</div>
			</div>
		</section>

		<section>
						<div class="section-title">
						<h2>Objectives</h2>
						</div>
			<div class="col-lg-12 row justify-content-center align-items-center">
						
						<div class="col-lg-4 col-md-6">
							<div class="single-costing-card">
								
	
								<p>Work as a Think Tank that develops and promotes alternative solutions to issues concerned with the Nepali society through policy research entrepreneurship</p>
	
								<p>Facilitate the formulation of appropriate policies and programs through studies on quality, efficacy and reliability of existing as well as proposed policies</p>
								
							</div>
						</div>
	
						<div class="col-lg-4 col-md-6">
							<div class="single-costing-card">
								
	
								<p>Strengthen state institutions as well as non-state institutions to enable coherent, rational and consistent policy formulation leading to quality life of every citizen.</p>
								<p>Produce and disseminate informational and educational materials relevant to pertinent policy problems and their potential solution</p>
								
							</div>
						</div>
	
						
					</div>
		</section>

	
		<section class="simple-steps-area pb-70">
			<div class="container">
				<div class="section-title">
					<h2>Approaches</h2>
					</div>

				<div class="row">
					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Research</h3>
							</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Policy Dilouge</h3>
							</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Advocacy</h3>
							</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Campaign</h3>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Publications</h3>
						</div>
					</div>

					
					
						
					</div>
				</div>
			</div>
		</section>

		<section class="simple-steps-area pb-70">
			<div class="container">
				<div class="section-title">
					<h2>Key Areas</h2>
					</div>

				<div class="row">
					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Governance</h3>
							</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Law and Policy</h3>
							</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Health</h3>
							</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Education</h3>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Natural Resources</h3>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-simple-steps icon-bg-style">
							
							<h3>Social Justice</h3>
						</div>
					</div>

					<div class="col-lg-3 col-sm-6">
						
					</div>
				</div>
			</div>
		</section>

	

		<?php include 'footer.php';?>
		
		<!-- Start Go Top Area -->
		<div class="go-top">
			<i class="ri-arrow-up-s-fill"></i>
			<i class="ri-arrow-up-s-fill"></i>
		</div>
		<!-- End Go Top Area -->

        <!-- Jquery Min JS -->
        <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script> 
        <!-- Bootstrap Bundle Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Meanmenu Min JS -->
		<script src="assets/js/meanmenu.min.js"></script>
		<!-- Owl Carousel Min JS -->
		<script src="assets/js/owl.carousel.min.js"></script>
		<!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
		<!-- Appear Min JS -->
        <script src="assets/js/appear.min.js"></script>
		<!-- Odometer Min JS -->
        <script src="assets/js/odometer.min.js"></script>
		<!-- Jarallax Min JS -->
        <script src="assets/js/jarallax.min.js"></script>
		<!-- Bootstrap Datepicker Min JS -->
        <script src="assets/js/bootstrap-datepicker.min.js"></script>
		<!-- Magnific Popup Min JS -->
        <script src="assets/js/magnific-popup.min.js"></script>
		<!-- Form Validator Min JS -->
		<script src="assets/js/form-validator.min.js"></script>
		<!-- Contact JS -->
		<script src="assets/js/contact-form-script.js"></script>
		<!-- Ajaxchimp Min JS -->
		<script src="assets/js/ajaxchimp.min.js"></script>
        <!-- Custom JS -->
		<script src="assets/js/custom.js"></script>
    </body>
</html>