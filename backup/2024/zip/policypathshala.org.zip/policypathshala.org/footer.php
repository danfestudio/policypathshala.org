<!-- Start Footer Area -->
<footer class="footer-area black-bg-color">
			<div class="container">
				<div class="row align-items-center justify-content-center">
					<div class="col-lg-4 col-sm-6">
						<div class="single-footer-widget bg-f9f5f1">
							<a href="index.html" class="logo">
								<img src="assets/images/cb/logo-white.png" alt="Image">
							</a>

							
							<ul class="social-icon">
								<li>
									<span>Follow us:</span>
								</li>
								<li>
									<a href="https://www.facebook.com/policypathshala" target="_blank">
										<i class="ri-facebook-fill"></i>
									</a>
								</li>
								
							</ul>
						</div>
					</div>

					<div class="col-lg-1 col-sm-6">
						
					</div>

					<div class="col-lg-3 col-sm-6">
						<div class="single-footer-widget">
							<h3>Links</h3>

							<ul class="import-link">
								<li>
									<a href="our-team.php">Our Team</a>
								</li>
								
								<li>
									<a href="news-and-media-coverage.php">News and Media Coverage</a>
								</li>
								<li>
									<a href="contact-us.php">Contact us</a>
								</li>
								
							</ul>
						</div>
					</div>

					

					<div class="col-lg-4 col-sm-6">
						<div class="single-footer-widget">
							

							<ul class="address">
								<li class="location">
									<i class="ri-map-pin-line"></i>
									<span>Address</span>
									5th Floor, Situ Plaza, Naxal, Nagpokhari
								</li>
								<li>
									<i class="ri-mail-line"></i>
									<span>Email</span>
									<a href="/cdn-cgi/l/email-protection#f29b9c949db2879c919ddc919d9f"><span class="__cf_email__" data-cfemail="bfd6d1d9d0ffcad1dcd091dcd0d2">info@policypathshala.org</span></a>
								</li>
								<li>
									<i class="ri-phone-line"></i>
									<span>Phone</span>
									<a href="tel:+977-01-4537793">+977-01-4537793</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- End Footer Area -->

		<!-- Start Copy Right Area -->
		<div class="copy-right-area">
			<div class="container">
				<p>
					Copyright <i class="ri-copyright-line"></i> 2023 Public Policy Pathshala
					
				</p>
			</div>
		</div>
		<!-- End Copy Right Area -->