﻿<!doctype html>
<html lang="zxx">
<?php include 'head.php';?>

    <body>
		<!-- Start Preloader Area -->
		<div class="preloader">
			<div class="lds-ripple">
				<div class="pl-flip-1 pl-flip-2"></div>
			</div>
		</div>
		<!-- End Preloader Area -->
		
		<!-- Start Header Area -->
		<?php include 'header.php';?>
		<!-- End Header Area -->

		<!-- Search Modal -->
		<div class="modal fade search-modal-area" id="exampleModalsrc">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<button type="button" data-bs-dismiss="modal" class="closer-btn">
						<i class="ri-close-line"></i>
					</button>

					<div class="modal-body">
						<form class="search-box">
							<div class="search-input">
								<input type="text" name="Search" placeholder="Search for..." class="form-control">

								<button type="submit" class="search-btn">
									<i class="ri-search-line"></i>
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Search Modal -->

		<!-- Start Page Title Area -->
		<div class="page-title-area bg-1">
			<div class="container">
				<div class="page-title-content">
					<h2>Activities</h2>

					<ul>
						<li>
							<a href="index.php">
								Home 
							</a>
						</li>

						<li class="active">Activities</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End Page Title Area -->

		<!-- Start Cart Area -->
		<section class="cart-area ptb-100">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						
						
							
								<table>
									<thead>
										<tr>
											<th width="8%"></th>
											
											<th width="28%"></th>
											<th width="50%"></th>
											<th width="2%"></th>
											<th width="12%"></th>
										</tr>
									</thead>
																			
									<tbody>
										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2018 - 2022  </h6></a>
											</td>

											

											

											<td class="product-name">
												<a href="#"><h6>Strengthening Local Health Governance</h6></a>
											</td>

											<td class="">
												<p>Since 2018, Public Policy Pathshala has been diligently providing policy assistance and facilitating selected local governments in partnership with The Asia Foundation, with a primary focus on strengthening local health governance.</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/1.jpg" target_blank>
													<img src="assets/images/cb/activities/1.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2022</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Review of Provincial and Municipal Health Policies, Acts and regulations</h6></a>
											</td>

											<td class="">
												<p>In collaboration with Strengthening Systems for Better Health(SSBH), Public Policy Pathshala conducted a comprehensive review and offered valuable legal, policy, and health inputs for the development of Karnali provincial and municipal-level health policies, acts, regulations, and guidelines. 
</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/0.jpg" target_blank>
													<img src="assets/images/cb/activities/0.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2020</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Orientation on
											Constitutional, legal
											and policy Provisions
											on Health and Practical
											Implications in the
											context of Federalism</h6></a>
											</td>

											<td class="">
												<p>Public Policy Pathshala (PPP) had the privilege of facilitating an orientation session on Constitutional, legislation, and Policy Provisions in health, along with their practical implications in the context of federalism. One Heart Worldwide (OHW), and it provided an opportunity for OHW staff members to enhance their understanding of the legal and policy framework surrounding healthcare.</p></td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/2.jpg" target_blank>
													<img src="assets/images/cb/activities/2.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										
										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2020</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Study on status of
													returnee labour
													migrants during
													COVID-19</h6></a>
												</td>

											<td class="">
															<p>
															PPP undertook a comprehensive research study on returned labor migrant workers in collaboration with Rural Enterprise and Remittance (RER)/SAMRIDDHI and The International Fund for Agricultural Development (IFAD). This research aimed to delve into the experiences and challenges faced by migrant workers upon their return, with a particular focus on the rural enterprise and remittance sectors. 

															</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/0.jpg" target_blank>
													<img src="assets/images/cb/activities/0.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2020</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Training on

													Constitution,
													legislation and policy
													provisions in health
													sector in federal
													context</h6></a>
												</td>

											<td class="">
																			<p>Public Policy Pathshala (PPP) facilited the discussion session on Constitutional, legislation, and Policy Provisions in the health sector within the context of federalism in collaboration with Strengthening Systems for Better Health (SSBH).</p></td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/0.jpg" target_blank>
													<img src="assets/images/cb/activities/0.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2020</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Supporting selected
													Local Government in
													preparing draft of
													Local Environment and
													Natural Resources
													Conservation Act</h6></a>
												</td>

											<td class="">
																			<p>In close collaboration with the World Wildlife Fund (WWF), Public Policy Pathshala (PPP) provided essential support to selected local governments in drafting the Local Environment and Natural Resources Conservation Act. This significant initiative aimed to enhance environmental and natural resource conservation at the local level.	</p></td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/3.jpg" target_blank>
													<img src="assets/images/cb/activities/3.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Workshop on
												constitutional
												provisions in health
												and federalism</h6></a>
												</td>

											<td class="">
																					<p>	In collaboration with the Association of International NGOs in Nepal (AIN), Public Policy Pathshala (PPP) organized an insightful "Orientation Workshop on Constitutional, Legal, and Policy Provisions on Health and Practical Implications in the Context of Federalism" for members of the AIN Health Group. This workshop served as a platform to enhance the participants' understanding of the constitutional, legal, and policy aspects related to health in the federal context.</p></td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/4.jpg" target_blank>
													<img src="assets/images/cb/activities/4.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Drafting prototype and
													model biodiversity acts
													and biodiversity
													standards by
													organizing two
													workshops for local governments-central
													cluster</h6></a>
												</td>

											<td class="">
																					<p>	In collaboration with World Wide Life Fund (WWF) Nepal and the Ministry of Federal Affairs and General Administration, Public Policy Pathshala (PPP) successfully implemented the project titled "Drafting Prototype and Model Environment and Natural Resources Act for Local Governments." As part of this initiative, PPP drafted and finalized the Model Environment and Natural Resources Act, incorporating valuable feedback from 18 local governments. This consolidated model act serves as a comprehensive framework to guide local governments in effectively managing and conserving their environment and natural resources.</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/0.jpg" target_blank>
													<img src="assets/images/cb/activities/0.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>	Policy and
													implementation
													challenges in the
													national health
													insurance programme</h6></a>
												</td>

											<td class="">
																					<p>
																					Public Policy Pathshala (PPP) and Anweshan collaborated on a policy research endeavor titled "Addressing Policy and Implementation Challenges in the National Health Insurance Programme." This research aimed to examine and assess the key challenges encountered during the implementation of the national health insurance program. 
																					</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/0.jpg" target_blank>
													<img src="assets/images/cb/activities/0.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>	Public Policy Dialogue
													on Newborn Health in
													Madhesh Province</h6></a>
												</td>

											<td class="">
																					<p>	
																					A provincial-level public policy dialogue was successfully organized in Janakpur to facilitate the sharing and discussion of findings derived from a series of consultations with local governments in the Madhesh province on newborn health. The esteemed participants of this dialogue included the Principal Secretary of the Madhesh Province government, the Secretary for the Ministry of Social Development, the Director from the Province Health Directorate, representatives from local governments, development partners, and distinguished experts from the health sector. This collaborative program provided a valuable platform for exchanging insights, experiences, and recommendations to further enhance newborn health initiatives in the province.	
																					</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/5.jpg" target_blank>
													<img src="assets/images/cb/activities/5.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>	Launch of the report on
													The Lancet Global
													Health Commission on
													High Quality Health
													Systems in the SDG
													Era</h6></a>
												</td>

											<td class="">
																					<p>
																					Public Policy Pathshala (PPP) in partnership with the Ministry of Health and Population (MoHP) of Nepal successfully hosted the launch event for the report titled "The Lancet Global Health Commission on High Quality Health Systems in the SDG Era" on 6th June 2019 in Kathmandu, Nepal. The distinguished event was graced by the presence of Honorable Upendra Yadav, Deputy Prime Minister, and Chair of the Lancet Global Health Commission, Dr. Margaret Kruk. The official launch of the report marked an important milestone in advancing discussions and actions towards achieving high-quality health systems in the context of the Sustainable Development Goals (SDGs).
																					</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/6.jpg" target_blank>
													<img src="assets/images/cb/activities/6.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>	Public Policy Dialogue
													on “Procurement
													Reform in Health
													Sector”</h6></a>
												</td>

											<td class="">
																					<p>
																					On 1st August 2019, Public Policy Pathshala (PPP) and The Asia Foundation jointly organized a significant Public Policy Dialogue on "Procurement Reform in the Health Sector" at Hotel Shangrila in Kathmandu. The primary objective of this dialogue was to deliberate on the Public Procurement Act and address the implementation challenges related to the procurement of medicines and equipment within the health sector. Esteemed participants included health procurement experts, members of parliament, local governance experts, donor representatives, civil society members, and other key stakeholders. The dialogue served as a platform for in-depth discussions, knowledge sharing, and collaboration towards enhancing the procurement system in the health sector.
																					</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/7.jpg" target_blank>
													<img src="assets/images/cb/activities/7.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>		Social Movement for
													Quality Health in
													Nepal</h6></a>
												</td>

											<td class="">
																					<p>
																					A Public Policy Dialogue under the theme of "Social Campaign for Quality Health" was jointly organized by Public Policy Pathshala (PPP) and the Lancet Global Health Commission. Esteemed participants from various sectors including Nepal's political, social, and public health spheres attended this dialogue. The distinguished attendees included Margaret Kruk, an esteemed associate professor at Harvard University, senior human rights activists, parliamentary members, senior health professionals, public health experts, development partners, and esteemed experts from the health sector. This dialogue served as a valuable platform for exchanging ideas, insights, and recommendations towards advancing the cause of quality health in Nepal.	
																					</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/8.jpg" target_blank>
													<img src="assets/images/cb/activities/8.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2018</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>		Public Policy Dialogue on “Pertinent Issues and Challenges of Public Health</h6></a>
												</td>

											<td class="">
																					<p>
																					In the wake of the endorsement of the Public Health Service Act, Public Policy Pathshala (PPP) and DFAT-TAF jointly co-hosted a highly significant Public Policy Dialogue on "Pertinent Issues and Challenges of Public Health" in 2018. This dialogue brought together key stakeholders, policymakers, experts, and practitioners from the public health domain to engage in thoughtful discussions and deliberations. The aim of the dialogue was to address the pressing issues and challenges faced in the field of public health and explore potential solutions.	
																					</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/9.jpg" target_blank>
													<img src="assets/images/cb/activities/9.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2018</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>An orientation to local
													governmental bodies of
													Madhesh Province
													on newborn care</h6></a>
												</td>

											<td class="">
																					<p>
																					In 2075 BS, a comprehensive workshop was conducted in eight districts of Province No. 2, namely Bara, Parsa, Rautahat, Siraha, Sarlahi, Mahottari, Saptari, and Dhanusha. The workshop brought together a diverse group of 136 local government chiefs, deputy chiefs, and subject matter experts. The primary focus of the workshop was to shed light on the constitutional provisions concerning newborn care and safe motherhood, emphasizing the crucial role of local government in this regard. The workshop provided a platform for insightful discussions, knowledge sharing, and capacity building, fostering a deeper understanding of the subject matter among the participants. The event served as a catalyst for strengthening efforts towards enhancing newborn care and ensuring the well-being of mothers within the respective districts.	
																				</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/10.jpg" target_blank>
													<img src="assets/images/cb/activities/10.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2018</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>A Natural Resources and
													Constitution: workshop
													on role of Local
													Governments and
													Representatives in the
													context of Federalism</h6></a>
												</td>

											<td class="">
																					<p>
																					A significant workshop was successfully concluded across four provinces, namely Madhesh Province (Simara), Gandaki Province (Kawasoti), Lumbini Province (Kohalpur), and Sudur-Paschim Province (Mahendranagar). The workshop brought together a total of 46 local government chiefs, deputy chiefs, and subject matter experts, all of whom engaged in insightful discussions and knowledge sharing. The primary focus of the workshop was to address the constitutional provisions pertaining to natural resource conservation and management, with a specific emphasis on the role of local government within the federal structure.
																				</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/11.jpg" target_blank>
													<img src="assets/images/cb/activities/11.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2018</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Policy Dialouge on Local Health Governance in Gandaki Province</h6></a>
												</td>

											<td class="">
																					<p>
																					A comprehensive multi-sector policy dialogue addressing the issues of local health governance was successfully organized in Pokhara in March 2018. The event witnessed the active participation of officials from more than 40 local governments, including Regional Director for Health (now known as Provincial Health Directorate), district level health officials (now known as Provincial Health Office), and esteemed health sector experts. The primary objective of the dialogue was to delve into the challenges posed by the federal transition in the health sector.
</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/16.jpg" target_blank>
													<img src="assets/images/cb/activities/16.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2016</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Public Policy Dialouge on Public Finance</h6></a>
												</td>

											<td class="">
																					<p>
																					Public Policy Pathshala organized a public policy dialogue centered around the critical topic of Public Finance, with a specific emphasis on the budget. Esteemed Public Finance expert, Jagdish Bhattarai, delivered an insightful presentation during the event, shedding light on key aspects and intricacies of the subject matter. The dialogue further featured engaging discussions involving prominent figures such as Gagan Thapa and renowned economist Dr. Bishwo Poudel. Their expertise and perspectives added depth and nuance to the discourse, providing attendees with a comprehensive understanding of the challenges and opportunities in the realm of public finance.
	
																				</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/12.jpg" target_blank>
													<img src="assets/images/cb/activities/12.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2016</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Haliya research</h6></a>
												</td>

											<td class="">
																					<p>
																					Public Policy Pathshala, in collaboration with Mukta Haliya Mahasangh and the Agricultural and Water Resources Committee of the Parliamentary Committee, undertook an extensive field study and conducted interactive sessions in the districts of Jajarkot, Surkhet, Darchula, Baitadi, Doti, and Dadeldhura. Additionally, in Kailali and Kanchanpur, field studies, in-depth discussions, and interactive sessions were conducted with various stakeholders, including the chair and members of the Agricultural and Water Resources Committee, Mukta Haliya Mahasangh, and the team from Public Policy Pathshala.		
																				</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/13.jpg" target_blank>
													<img src="assets/images/cb/activities/13.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										
										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2015</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Land reform in Nepal :
											Six decades of debates</h6></a>
												</td>

											<td class="">
																								<p>
																								An interactive program on the topic of six decades of land reform debates in Nepal was conducted in Kathmandu, Kailali, Doti, and Jhapa. The program brought together political leaders, journalists, land rights activists, and various stakeholders to engage in meaningful discussions. Constituent Assembly members, Nepali Congress youth leaders, land rights activists, representatives of political parties, journalists, and other stakeholders actively participated in the program, which included both interactive sessions and on-site visits. The program aimed to foster dialogue and exchange of ideas regarding land reform in Nepal, involving key stakeholders from different sectors and perspectives.	
																							</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/14.jpg" target_blank>
													<img src="assets/images/cb/activities/14.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2011</h6></a>
											</td>

											

											<td class="product-name">
														<a href="#"><h6>Role of youth in Social
												democracy and Nepali
												politics</h6></a>
												</td>

											<td class="">
											<p>An interactive program focusing on the role of youth in social democracy and Nepali politics was conducted in Kathmandu, Pokhara, Palpa, and Jhapa. The program brought together young leaders from various political parties and local leaders who are actively engaged in the socio-political field. The program aimed to facilitate meaningful discussions and exchange of ideas among these emerging leaders, exploring their perspectives on the role of youth in promoting social democracy and contributing to the political landscape of Nepal.

																			</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/15.jpg" target_blank>
													<img src="assets/images/cb/activities/15.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										
	
									</tbody>
								</table>
							</div>
						</form>
		
						
					</div>

					
				</div>
			</div>
		</section>
		<!-- End Cart Area -->

		<?php include 'footer.php';?>
		
		<!-- Start Go Top Area -->
		<div class="go-top">
			<i class="ri-arrow-up-s-fill"></i>
			<i class="ri-arrow-up-s-fill"></i>
		</div>
		<!-- End Go Top Area -->

        <!-- Jquery Min JS -->
        <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script> 
        <!-- Bootstrap Bundle Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Meanmenu Min JS -->
		<script src="assets/js/meanmenu.min.js"></script>
		<!-- Owl Carousel Min JS -->
		<script src="assets/js/owl.carousel.min.js"></script>
		<!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
		<!-- Appear Min JS -->
        <script src="assets/js/appear.min.js"></script>
		<!-- Odometer Min JS -->
        <script src="assets/js/odometer.min.js"></script>
		<!-- Jarallax Min JS -->
        <script src="assets/js/jarallax.min.js"></script>
		<!-- Bootstrap Datepicker Min JS -->
        <script src="assets/js/bootstrap-datepicker.min.js"></script>
		<!-- Magnific Popup Min JS -->
        <script src="assets/js/magnific-popup.min.js"></script>
		<!-- Form Validator Min JS -->
		<script src="assets/js/form-validator.min.js"></script>
		<!-- Contact JS -->
		<script src="assets/js/contact-form-script.js"></script>
		<!-- Ajaxchimp Min JS -->
		<script src="assets/js/ajaxchimp.min.js"></script>
        <!-- Custom JS -->
		<script src="assets/js/custom.js"></script>
    </body>
</html>