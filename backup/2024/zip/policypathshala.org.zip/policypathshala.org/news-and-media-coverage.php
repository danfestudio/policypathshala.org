﻿<!doctype html>
<html lang="zxx">
	<?php include 'head.php';?>	

    <body>
		<!-- Start Preloader Area -->
		<div class="preloader">
			<div class="lds-ripple">
				<div class="pl-flip-1 pl-flip-2"></div>
			</div>
		</div>
		<!-- End Preloader Area -->
		
		<!-- Start Header Area -->
		 <?php include 'header.php';?>	
		<!-- End Header Area -->

		<!-- Search Modal -->
		<div class="modal fade search-modal-area" id="exampleModalsrc">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<button type="button" data-bs-dismiss="modal" class="closer-btn">
						<i class="ri-close-line"></i>
					</button>

					<div class="modal-body">
						<form class="search-box">
							<div class="search-input">
								<input type="text" name="Search" placeholder="Search for..." class="form-control">

								<button type="submit" class="search-btn">
									<i class="ri-search-line"></i>
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Search Modal -->

		<!-- Start Page Title Area -->
		<div class="page-title-area bg-1">
			<div class="container">
				<div class="page-title-content">
					<h2>News and Media Coverage</h2>

					<ul>
						<li>
							<a href="index.php">
								Home 
							</a>
						</li>

						<li class="active">News and Media Coverage</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End Page Title Area -->

		<!-- Start Blog Area -->
		<section class="blog-post-area ptb-100">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="row justify-content-md-center">
							<div class="col-lg-4 col-md-6">
								<div class="single-blog">
									<a href="blog-details.html" class="blog-img">
										<img src="assets/images/cb/news/1.jpg" alt="Image">
										
									</a>
		
									<div class="blog-content">
										<ul>
											<li>
												<i class="ri-calendar-line"></i>
												<span>2८ असार २०७६</span>
											</li>
										</ul>
			
										<h3>
											<a href="https://www.himalkhabar.com/news/13167" target="_blank">
											दुःखी नेपाली
											</a>
										</h3>
			
										<p>विश्वभर नै न्यूनतम गुुणस्तर सुुनिश्चित नभएकोे स्वास्थ्य सेवालाई व्यर्थको, प्रभावहीन र अनैतिक मानिन्छ। यो मापदण्डका आधारमा नेपालको स्वास्थ्य सेवाको स्थिति कहालीलाग्दो छ।</p>
									</div>
								</div>
							</div>

							<div class="col-lg-4 col-md-6">
								<div class="single-blog">
									<a href="blog-details.html" class="blog-img">
										<img src="assets/images/cb/news/2.jpg" alt="Image">
										
									</a>
		
									<div class="blog-content">
										<ul>
											<li>
												<i class="ri-calendar-line"></i>
												<span>8 June 2019</span>
											</li>
										</ul>
			
										<h3>
											<a href="https://kathmandupost.com/valley/2019/06/08/nepal-will-struggle-to-achieve-sdgs-and-universal-health-coverage-without-ensuring-quality-health-care-experts-say" target="_blank">
											Nepal will struggle to achieve SDGs and universal health coverage without ensuring quality health care, experts say

											</a>
										</h3>
			
										</div>
								</div>
							</div>
		
							

						
						</div>
					</div>

				

					
				</div>
			</div>
		</section>
		<!-- End Blog Area -->

		
		<?php include 'footer.php';?>	
		
		<!-- Start Go Top Area -->
		<div class="go-top">
			<i class="ri-arrow-up-s-fill"></i>
			<i class="ri-arrow-up-s-fill"></i>
		</div>
		<!-- End Go Top Area -->

        <!-- Jquery Min JS -->
        <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script> 
        <!-- Bootstrap Bundle Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Meanmenu Min JS -->
		<script src="assets/js/meanmenu.min.js"></script>
		<!-- Owl Carousel Min JS -->
		<script src="assets/js/owl.carousel.min.js"></script>
		<!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
		<!-- Appear Min JS -->
        <script src="assets/js/appear.min.js"></script>
		<!-- Odometer Min JS -->
        <script src="assets/js/odometer.min.js"></script>
		<!-- Jarallax Min JS -->
        <script src="assets/js/jarallax.min.js"></script>
		<!-- Bootstrap Datepicker Min JS -->
        <script src="assets/js/bootstrap-datepicker.min.js"></script>
		<!-- Magnific Popup Min JS -->
        <script src="assets/js/magnific-popup.min.js"></script>
		<!-- Form Validator Min JS -->
		<script src="assets/js/form-validator.min.js"></script>
		<!-- Contact JS -->
		<script src="assets/js/contact-form-script.js"></script>
		<!-- Ajaxchimp Min JS -->
		<script src="assets/js/ajaxchimp.min.js"></script>
        <!-- Custom JS -->
		<script src="assets/js/custom.js"></script>
    </body>
</html>