﻿<!doctype html>
<html lang="zxx">
    <?php include 'head.php';?>	
    <body>
		<!-- Start Preloader Area -->
		<div class="preloader">
			<div class="lds-ripple">
				<div class="pl-flip-1 pl-flip-2"></div>
			</div>
		</div>
		<!-- End Preloader Area -->
		
		<!-- Start Header Area -->
		<?php include 'header.php';?>	
		<!-- End Header Area -->

		<!-- Search Modal -->
		<div class="modal fade search-modal-area" id="exampleModalsrc">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<button type="button" data-bs-dismiss="modal" class="closer-btn">
						<i class="ri-close-line"></i>
					</button>

					<div class="modal-body">
						<form class="search-box">
							<div class="search-input">
								<input type="text" name="Search" placeholder="Search for..." class="form-control">

								<button type="submit" class="search-btn">
									<i class="ri-search-line"></i>
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Search Modal -->

		<!-- Start Page Title Area -->
		<div class="page-title-area bg-1">
			<div class="container">
				<div class="page-title-content">
					<h2>Research</h2>

					<ul>
						<li>
							<a href="index.php">
								Home 
							</a>
						</li>

						<li class="active">Research</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End Page Title Area -->

		<!-- Start Events Area -->
		

		<!-- End Events Area -->
		<section class="cart-area ptb-100">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						
						
							
								<table>
									<thead>
										<tr>
											<th width="8%"></th>
											
											<th width="28%"></th>
											<th width="50%"></th>
											<th width="2%"></th>
											<th width="12%"></th>
										</tr>
									</thead>
																			
									<tbody>

									<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2020</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>	Nepal Local Health Governance Situational and Political Economy Analysis Report</h6></a>
												</td>

											<td class="">
												
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/0.jpg" target_blank>
													<img src="assets/images/cb/activities/0.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

									<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2020</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Study on status of
													returnee labour
													migrants during
													COVID-19</h6></a>
												</td>

											<td class="">
															<p>PPP conducted a research on returned labor migrant
												workers for Rural Enterprise and Remittance
												(RER)/SAMRIDDHI and The International Fund for
												Agricultural Development (IFAD).</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/0.jpg" target_blank>
													<img src="assets/images/cb/activities/0.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>

										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2019</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>	Policy and
													implementation
													challenges in the
													national health
													insurance programme</h6></a>
												</td>

											<td class="">
																					<p>	Anweshan and PPP conducted the research on “Policy
													and implementation challenges in the national health
													insurance programme” in 2019.</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/0.jpg" target_blank>
													<img src="assets/images/cb/activities/0.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>
									
										<tr class="cnb">
											<td class="product-name">
												
												<a href="#"><h6>2016</h6></a>
											</td>

											

											<td class="product-name">
												<a href="#"><h6>Haliya research</h6></a>
												</td>

											<td class="">
																					<p>
																					In collaboration with Mukta Haliya Mahasangh and
												Agriculture and Water Resources Committee, the
												team of Mukta Haliya Mahasangh and Public Policy
												Pathshala conducted field study and interaction in
												Jajarkot, Surkhet, Darchula, Baitadi, Doti and
												Dadeldhura. In Kailali and Kanchanpur, on-site
												studies and discussions and interactions were held
												with the stakeholders. The Agriculture and Water
												Resources Committee was chaired by Gagan Thapa
												and was attended by committee members and
												representatives of Mukta Haliya Federation and the
												PPP team.</p>
											</td>

											<td class="">
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/activities/13.jpg" target_blank>
													<img src="assets/images/cb/activities/13.jpg" alt="Image">
												</a>
											</td>
		
											
		
											
										</tr>
								
										
								
								
								
									
								
								
								
									
								
								
									</tbody>
								</table>
							</div>
						</form>
		
						
					</div>

					
				</div>
			</div>
		</section>

		<?php include 'footer.php';?>
		
		<!-- Start Go Top Area -->
		<div class="go-top">
			<i class="ri-arrow-up-s-fill"></i>
			<i class="ri-arrow-up-s-fill"></i>
		</div>
		<!-- End Go Top Area -->

        <!-- Jquery Min JS -->
        <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script> 
        <!-- Bootstrap Bundle Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Meanmenu Min JS -->
		<script src="assets/js/meanmenu.min.js"></script>
		<!-- Owl Carousel Min JS -->
		<script src="assets/js/owl.carousel.min.js"></script>
		<!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
		<!-- Appear Min JS -->
        <script src="assets/js/appear.min.js"></script>
		<!-- Odometer Min JS -->
        <script src="assets/js/odometer.min.js"></script>
		<!-- Jarallax Min JS -->
        <script src="assets/js/jarallax.min.js"></script>
		<!-- Bootstrap Datepicker Min JS -->
        <script src="assets/js/bootstrap-datepicker.min.js"></script>
		<!-- Magnific Popup Min JS -->
        <script src="assets/js/magnific-popup.min.js"></script>
		<!-- Form Validator Min JS -->
		<script src="assets/js/form-validator.min.js"></script>
		<!-- Contact JS -->
		<script src="assets/js/contact-form-script.js"></script>
		<!-- Ajaxchimp Min JS -->
		<script src="assets/js/ajaxchimp.min.js"></script>
        <!-- Custom JS -->
		<script src="assets/js/custom.js"></script>
    </body>
</html>