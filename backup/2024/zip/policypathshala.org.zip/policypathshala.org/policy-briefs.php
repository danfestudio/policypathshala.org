﻿<!doctype html>
<html lang="zxx">
<?php include 'head.php';?>

    <body>
		<!-- Start Preloader Area -->
		<div class="preloader">
			<div class="lds-ripple">
				<div class="pl-flip-1 pl-flip-2"></div>
			</div>
		</div>
		<!-- End Preloader Area -->
		
		<!-- Start Header Area -->
		<?php include 'header.php';?>
		<!-- End Header Area -->

		<!-- Search Modal -->
		<div class="modal fade search-modal-area" id="exampleModalsrc">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<button type="button" data-bs-dismiss="modal" class="closer-btn">
						<i class="ri-close-line"></i>
					</button>

					<div class="modal-body">
						<form class="search-box">
							<div class="search-input">
								<input type="text" name="Search" placeholder="Search for..." class="form-control">

								<button type="submit" class="search-btn">
									<i class="ri-search-line"></i>
								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- Search Modal -->

		<!-- Start Page Title Area -->
		<div class="page-title-area bg-1">
			<div class="container">
				<div class="page-title-content">
					<h2>Policy Briefs</h2>

					<ul>
						<li>
							<a href="index.php">
								Home 
							</a>
						</li>

						<li class="active">Policy Briefs</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End Page Title Area -->

		<!-- Start Cart Area -->
		<section class="cart-area ptb-100">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">

						<form class="cart-controller">
							<div class="cart-table table-responsive">
								<table class="table table-bordered">
									<thead>
										<tr>
											<th scope="col" width="10%">SN</th>
											<th scope="col" width="12%">Year</th>
											
											<th scope="col">Title</th>
											<th scope="col"  width="13%">Image</th>
											<th scope="col" width="25%">PDF Link</th>
										</tr>
									</thead> 
																			
									<tbody>
										<tr>
											<td class="product-name">
												
												<a href="#">१	</a>
											</td>

											<td class="product-name">
												
												<a href="#">२०१९</a>
											</td>

											

											

											<td class="product-name">
												<a href="#">संबिधान, जनस्वास्थ्यका चुनौती र  जनस्वास्थ्य सेवा ऐन कार्यान्वयनको सवाल</a>
											</td>
											
											
											<td class="product-thumbnail">
												<a href="assets/images/cb/publications/POLICY-BRIEF.jpg" target_blank>
													<img src="assets/images/cb/publications/POLICY-BRIEF.jpg" alt="Image">
												</a>
											</td>
		
											<td class="product-price">
												<a href="assets/pdf/POLICY-BRIEF.pdf">Download link</a>
											</td>
		
											
										</tr>

										
										
	
									</tbody>
								</table>
							</div>
						</form>
		
						<
					</div>

					
				</div>
			</div>
		</section>
		<!-- End Cart Area -->

		<?php include 'footer.php';?>
		
		<!-- Start Go Top Area -->
		<div class="go-top">
			<i class="ri-arrow-up-s-fill"></i>
			<i class="ri-arrow-up-s-fill"></i>
		</div>
		<!-- End Go Top Area -->

        <!-- Jquery Min JS -->
        <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery.min.js"></script> 
        <!-- Bootstrap Bundle Min JS -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <!-- Meanmenu Min JS -->
		<script src="assets/js/meanmenu.min.js"></script>
		<!-- Owl Carousel Min JS -->
		<script src="assets/js/owl.carousel.min.js"></script>
		<!-- Wow Min JS -->
        <script src="assets/js/wow.min.js"></script>
		<!-- Appear Min JS -->
        <script src="assets/js/appear.min.js"></script>
		<!-- Odometer Min JS -->
        <script src="assets/js/odometer.min.js"></script>
		<!-- Jarallax Min JS -->
        <script src="assets/js/jarallax.min.js"></script>
		<!-- Bootstrap Datepicker Min JS -->
        <script src="assets/js/bootstrap-datepicker.min.js"></script>
		<!-- Magnific Popup Min JS -->
        <script src="assets/js/magnific-popup.min.js"></script>
		<!-- Form Validator Min JS -->
		<script src="assets/js/form-validator.min.js"></script>
		<!-- Contact JS -->
		<script src="assets/js/contact-form-script.js"></script>
		<!-- Ajaxchimp Min JS -->
		<script src="assets/js/ajaxchimp.min.js"></script>
        <!-- Custom JS -->
		<script src="assets/js/custom.js"></script>
    </body>
</html>