package main

import "chetanbudathoki/policypathshala/server"

func main() {
	server.StartServer()
}
