package backend

import (
	"chetanbudathoki/policypathshala/database"
	"html/template"
	"net/http"
	"path/filepath"
	"strconv"
)

func AddActivityPageHandler(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.ParseFiles(filepath.Join("backend", "add-activity.html"), filepath.Join("backend", "header.html"), filepath.Join("backend", "footer.html"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl.ExecuteTemplate(w, "add-activity.html", nil)
}

func AddActivityHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	title := r.FormValue("title")
	description := r.FormValue("description")
	imageURL := r.FormValue("image_url")
	category := r.FormValue("category")
	dateStr := r.FormValue("date")

	date, err := strconv.Atoi(dateStr)
	if err != nil {
		http.Error(w, "Invalid date format", http.StatusBadRequest)
		return
	}

	activities, err := database.LoadActivities()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	newID := len(activities) + 1
	newActivity := database.Activity{
		ID:          newID,
		Title:       title,
		Description: description,
		ImageURL:    imageURL,
		Category:    category,
		Date:        date,
	}

	activities = append(activities, newActivity)
	err = database.SaveActivities(activities)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/dashboard/activities", http.StatusSeeOther)
}
