package backend

import (
	"net/http"
)

func DashboardActivityHandler(w http.ResponseWriter, r *http.Request) {
	Templates(w, "activity.html", nil, true)
}