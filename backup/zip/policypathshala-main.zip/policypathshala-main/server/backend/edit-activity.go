package backend

import (
	"chetanbudathoki/policypathshala/database"
	"html/template"
	"net/http"
	"path/filepath"
	"strconv"
)

func EditActivityPageHandler(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "ID is required", http.StatusBadRequest)
		return
	}

	activityID, err := strconv.Atoi(id)
	if err != nil {
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return
	}

	activities, err := database.LoadActivities()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	var activity *database.Activity
	for _, a := range activities {
		if a.ID == activityID {
			activity = &a
			break
		}
	}

	if activity == nil {
		http.Error(w, "Activity not found", http.StatusNotFound)
		return
	}

	data := struct {
		Title    string
		Activity *database.Activity
	}{
		Title:    "Edit Activity",
		Activity: activity,
	}

	tmpl, err := template.ParseFiles(filepath.Join("backend", "edit-activity.html"), filepath.Join("backend", "header.html"), filepath.Join("backend", "footer.html"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl.ExecuteTemplate(w, "edit-activity.html", data)
}

func UpdateActivityHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	id := r.FormValue("id")
	title := r.FormValue("title")
	description := r.FormValue("description")
	imageURL := r.FormValue("image_url")
	category := r.FormValue("category")
	dateStr := r.FormValue("date")

	activityID, err := strconv.Atoi(id)
	if err != nil {
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return
	}

	date, err := strconv.Atoi(dateStr)
	if err != nil {
		http.Error(w, "Invalid date format", http.StatusBadRequest)
		return
	}

	activities, err := database.LoadActivities()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	updated := false
	for i, a := range activities {
		if a.ID == activityID {
			activities[i].Title = title
			activities[i].Description = description
			activities[i].ImageURL = imageURL
			activities[i].Category = category
			activities[i].Date = date
			updated = true
			break
		}
	}

	if !updated {
		http.Error(w, "Activity not found", http.StatusNotFound)
		return
	}

	err = database.SaveActivities(activities)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/dashboard/activities", http.StatusSeeOther)
}
