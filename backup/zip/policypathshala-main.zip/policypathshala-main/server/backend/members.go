package backend

import (
	"chetanbudathoki/policypathshala/database"
	"encoding/json"
	"net/http"
	"os"
	"strconv"
)

func DashboardMembersHandler(w http.ResponseWriter, r *http.Request) {
	members, err := database.LoadMembers()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	data := struct {
		Title   string
		Members []database.Member
	}{
		Title:   "Members Page",
		Members: members,
	}

	Templates(w, "members.html", data, true)
}

func UpdateMemberStatusHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	id := r.FormValue("id")
	status := r.FormValue("status")

	members, err := database.LoadMembers()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	memberID, err := strconv.Atoi(id)
	if err != nil {
		http.Error(w, "Invalid ID value", http.StatusBadRequest)
		return
	}

	statusValue, err := strconv.Atoi(status)
	if err != nil {
		http.Error(w, "Invalid status value", http.StatusBadRequest)
		return
	}

	updated := false
	for i, member := range members {
		if member.ID == memberID {
			members[i].Status = statusValue
			updated = true
			break
		}
	}

	if !updated {
		http.Error(w, "Member not found", http.StatusNotFound)
		return
	}

	file, err := os.Create("database/members.json")
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	if err := encoder.Encode(members); err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}
