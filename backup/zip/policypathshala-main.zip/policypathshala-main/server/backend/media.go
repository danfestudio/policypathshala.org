package backend

import (
	"chetanbudathoki/policypathshala/database"
	"html/template"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

func MediaHandler(w http.ResponseWriter, r *http.Request) {
	images, err := database.LoadImages()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	data := struct {
		Title  string
		Images []database.Image
	}{
		Title:  "Media Library",
		Images: images,
	}

	tmpl, err := template.ParseFiles(filepath.Join("backend", "media.html"), filepath.Join("backend", "header.html"), filepath.Join("backend", "footer.html"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl.ExecuteTemplate(w, "media.html", data)
}

func UploadHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	file, header, err := r.FormFile("image")
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	defer file.Close()

	filename := header.Filename
	filepath := filepath.Join("assets/images", filename)
	out, err := os.Create(filepath)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	defer out.Close()

	_, err = out.ReadFrom(file)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	images, err := database.LoadImages()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	imageID := len(images) + 1
	description := r.FormValue("description")
	uploadTime := time.Now()
	fileInfo, err := out.Stat()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	size := fileInfo.Size() / 1024 // Size in KB

	newImage := database.Image{
		ID:          imageID,
		URL:         "/assets/images/" + filename,
		Description: description,
		UploadTime:  uploadTime,
		Size:        int(size),
	}

	images = append(images, newImage)
	err = database.SaveImages(images)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/dashboard/media", http.StatusSeeOther)
}

func UploadPageHandler(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.ParseFiles(filepath.Join("backend", "upload.html"), filepath.Join("backend", "header.html"), filepath.Join("backend", "footer.html"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	data := struct {
		Title string
	}{
		Title: "Upload Image",
	}

	tmpl.ExecuteTemplate(w, "upload.html", data)
}
