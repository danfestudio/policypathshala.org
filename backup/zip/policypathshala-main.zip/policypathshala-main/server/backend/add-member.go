package backend

import (
	"chetanbudathoki/policypathshala/database"
	"html/template"
	"net/http"
	"path/filepath"
	"strconv"
)

func AddMemberPageHandler(w http.ResponseWriter, r *http.Request) {
	tmpl, err := template.ParseFiles(filepath.Join("backend", "add-member.html"), filepath.Join("backend", "header.html"), filepath.Join("backend", "footer.html"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl.ExecuteTemplate(w, "add-member.html", nil)
}

func AddMemberHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	name := r.FormValue("name")
	username := r.FormValue("username")
	email := r.FormValue("email")
	position := r.FormValue("position")
	mobile := r.FormValue("mobile")
	about := r.FormValue("about")
	category := r.FormValue("category")
	hierarchyStr := r.FormValue("hierarchy")
	facebook := r.FormValue("facebook")
	twitter := r.FormValue("twitter")
	instagram := r.FormValue("instagram")
	linkedin := r.FormValue("linkedin")
	image := r.FormValue("image")

	hierarchy, err := strconv.Atoi(hierarchyStr)
	if err != nil {
		http.Error(w, "Invalid hierarchy value", http.StatusBadRequest)
		return
	}

	// Set default status to 1
	status := 1

	members, err := database.LoadMembers()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	newID := len(members) + 1
	newMember := database.Member{
		ID:        newID,
		Name:      name,
		Username:  username,
		Email:     email,
		Position:  position,
		Mobile:    mobile,
		About:     about,
		Category:  category,
		Hierarchy: hierarchy,
		Status:    status,
		Facebook:  facebook,
		Twitter:   twitter,
		Instagram: instagram,
		LinkedIn:  linkedin,
		Image:     image,
	}

	members = append(members, newMember)
	err = database.SaveMembers(members)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/dashboard/members", http.StatusSeeOther)
}
