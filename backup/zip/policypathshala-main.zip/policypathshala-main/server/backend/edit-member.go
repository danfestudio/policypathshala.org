package backend

import (
	"chetanbudathoki/policypathshala/database"
	"html/template"
	"net/http"
	"path/filepath"
	"strconv"
)

func EditMemberPageHandler(w http.ResponseWriter, r *http.Request) {
	id := r.URL.Query().Get("id")
	if id == "" {
		http.Error(w, "ID is required", http.StatusBadRequest)
		return
	}

	memberID, err := strconv.Atoi(id)
	if err != nil {
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return
	}

	members, err := database.LoadMembers()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	var member *database.Member
	for _, m := range members {
		if m.ID == memberID {
			member = &m
			break
		}
	}

	if member == nil {
		http.Error(w, "Member not found", http.StatusNotFound)
		return
	}

	data := struct {
		Title  string
		Member *database.Member
	}{
		Title:  "Edit Member",
		Member: member,
	}

	tmpl, err := template.ParseFiles(filepath.Join("backend", "edit-member.html"), filepath.Join("backend", "header.html"), filepath.Join("backend", "footer.html"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl.ExecuteTemplate(w, "edit-member.html", data)
}

func UpdateMemberHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	id := r.FormValue("id")
	name := r.FormValue("name")
	username := r.FormValue("username")
	email := r.FormValue("email")
	position := r.FormValue("position")
	mobile := r.FormValue("mobile")
	about := r.FormValue("about")
	category := r.FormValue("category")
	hierarchyStr := r.FormValue("hierarchy")
	facebook := r.FormValue("facebook")
	twitter := r.FormValue("twitter")
	instagram := r.FormValue("instagram")
	linkedin := r.FormValue("linkedin")
	image := r.FormValue("image")

	memberID, err := strconv.Atoi(id)
	if err != nil {
		http.Error(w, "Invalid ID", http.StatusBadRequest)
		return
	}

	hierarchy, err := strconv.Atoi(hierarchyStr)
	if err != nil {
		http.Error(w, "Invalid hierarchy value", http.StatusBadRequest)
		return
	}

	members, err := database.LoadMembers()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	updated := false
	for i, m := range members {
		if m.ID == memberID {
			members[i].Name = name
			members[i].Username = username
			members[i].Email = email
			members[i].Position = position
			members[i].Mobile = mobile
			members[i].About = about
			members[i].Category = category
			members[i].Hierarchy = hierarchy
			members[i].Facebook = facebook
			members[i].Twitter = twitter
			members[i].Instagram = instagram
			members[i].LinkedIn = linkedin
			members[i].Image = image
			updated = true
			break
		}
	}

	if !updated {
		http.Error(w, "Member not found", http.StatusNotFound)
		return
	}

	err = database.SaveMembers(members)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/dashboard/members", http.StatusSeeOther)
}
