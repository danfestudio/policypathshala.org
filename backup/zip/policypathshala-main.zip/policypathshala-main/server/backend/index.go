package backend

import (
	"net/http"
)

func DashboardIndexHandler(w http.ResponseWriter, r *http.Request) {
	Templates(w, "index.html", nil, true)
}