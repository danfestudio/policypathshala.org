package backend

import (
	"chetanbudathoki/policypathshala/database"
	"encoding/json"
	"html/template"
	"net/http"
	"path/filepath"
	"strconv"
)

func DashboardActivitiesHandler(w http.ResponseWriter, r *http.Request) {
	activities, err := database.LoadActivities()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	data := struct {
		Title      string
		Activities []database.Activity
	}{
		Title:      "Activities Page",
		Activities: activities,
	}

	tmpl, err := template.ParseFiles(filepath.Join("backend", "activities.html"), filepath.Join("backend", "header.html"), filepath.Join("backend", "footer.html"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl.ExecuteTemplate(w, "activities.html", data)
}

func UpdateActivityStatusHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Invalid request method", http.StatusMethodNotAllowed)
		return
	}

	id := r.FormValue("id")
	status := r.FormValue("status")

	activities, err := database.LoadActivities()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	activityID, err := strconv.Atoi(id)
	if err != nil {
		http.Error(w, "Invalid ID value", http.StatusBadRequest)
		return
	}

	statusValue, err := strconv.Atoi(status)
	if err != nil {
		http.Error(w, "Invalid status value", http.StatusBadRequest)
		return
	}

	updated := false
	for i, activity := range activities {
		if activity.ID == activityID {
			activities[i].Status = statusValue
			updated = true
			break
		}
	}

	if !updated {
		http.Error(w, "Activity not found", http.StatusNotFound)
		return
	}

	err = database.SaveActivities(activities)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]bool{"success": true})
}
