package backend

import (
	"html/template"
	"net/http"
	"path/filepath"
)

// Templates parses and executes the given templates.
func Templates(w http.ResponseWriter, tmpl string, data interface{}, isBackend bool) {
	var tmplPath, headerPath, footerPath string

	if isBackend {
		tmplPath = filepath.Join("backend", tmpl)
		headerPath = filepath.Join("backend", "header.html")
		footerPath = filepath.Join("backend", "footer.html")
	} else {
		tmplPath = filepath.Join("public", tmpl)
		headerPath = filepath.Join("public", "header.html")
		footerPath = filepath.Join("public", "footer.html")
	}

	t, err := template.ParseFiles(headerPath, footerPath, tmplPath)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	err = t.ExecuteTemplate(w, filepath.Base(tmpl), data)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}
