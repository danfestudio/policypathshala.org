package backend

import (
	"net/http"
)

func DashboardPolicyDilougesHandler(w http.ResponseWriter, r *http.Request) {
	Templates(w, "policy-dilouges.html", nil, true)
}