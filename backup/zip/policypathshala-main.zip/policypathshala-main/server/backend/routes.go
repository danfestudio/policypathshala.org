package backend

import (
	"net/http"
)

func Routes() {
	http.HandleFunc("/dashboard", DashboardIndexHandler)

	http.HandleFunc("/dashboard/members", DashboardMembersHandler)
	http.HandleFunc("/dashboard/members/update", UpdateMemberStatusHandler)

	http.HandleFunc("/dashboard/add-member", AddMemberPageHandler)
	http.HandleFunc("/dashboard/add-member/submit", AddMemberHandler)

	http.HandleFunc("/dashboard/edit-member", EditMemberPageHandler)
	http.HandleFunc("/dashboard/edit-member/update", UpdateMemberHandler)

	http.HandleFunc("/dashboard/activities", DashboardActivitiesHandler)
	http.HandleFunc("/dashboard/activities/update", UpdateActivityStatusHandler)

	http.HandleFunc("/dashboard/edit-activity", EditActivityPageHandler)
	http.HandleFunc("/dashboard/edit-activity/update", UpdateActivityHandler)

	http.HandleFunc("/dashboard/activity", DashboardActivityHandler)
	
	http.HandleFunc("/dashboard/add-activity", AddActivityPageHandler)
	http.HandleFunc("/dashboard/add-activity/submit", AddActivityHandler)

	http.HandleFunc("/dashboard/policy-dilouges", DashboardPolicyDilougesHandler)
	
	http.HandleFunc("/dashboard/media", MediaHandler)
	http.HandleFunc("/dashboard/media/upload", UploadHandler)
	http.HandleFunc("/dashboard/upload", UploadPageHandler)

	// Serve static files from the assets directory
	http.Handle("/assets/", http.StripPrefix("/assets/", http.FileServer(http.Dir("assets"))))

	fs := http.FileServer(http.Dir("./backend/static"))
	http.Handle("/dashboard/static/", http.StripPrefix("/dashboard/static/", fs))
}
