package server

import (
	"chetanbudathoki/policypathshala/server/backend"
	"chetanbudathoki/policypathshala/server/public"
	"net/http"
)

func StartServer() {
	public.Routes()
	backend.Routes()	

	http.ListenAndServe(":8080", nil)
}
 