package public

import (
	"net/http"
)

func AboutHandler(w http.ResponseWriter, r *http.Request) {
	templates(w, "about.html", nil)
}
