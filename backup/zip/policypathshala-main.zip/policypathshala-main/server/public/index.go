package public

import (
	"net/http"
)

func PublicIndexHandler(w http.ResponseWriter, r *http.Request) {
	templates(w, "index.html", nil)
}
