package public

import (
	"chetanbudathoki/policypathshala/database"
	"net/http"
	"sort"
)

func PublicActivitiesHandler(w http.ResponseWriter, r *http.Request) {
	activities, err := database.LoadActivities()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	var filteredActivities []database.Activity
	for _, activity := range activities {
		if activity.Category == "activity" {
			filteredActivities = append(filteredActivities, activity)
		}
	}

	sort.Slice(filteredActivities, func(i, j int) bool {
		return filteredActivities[i].Date > filteredActivities[j].Date
	})

	data := struct {
		Title      string
		Activities []database.Activity
	}{
		Title:      "Activities",
		Activities: filteredActivities,
	}

	templates(w, "activities.html", data)
}
