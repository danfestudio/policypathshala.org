package public

import (
	"net/http"
)

func NewsandMediaHandler(w http.ResponseWriter, r *http.Request) {
	templates(w, "news-media.html", nil)
}
