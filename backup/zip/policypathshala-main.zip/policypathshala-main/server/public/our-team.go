package public

import (
	"chetanbudathoki/policypathshala/database"
	"html/template"
	"net/http"
	"path/filepath"
	"sort"
)

func OurTeamHandler(w http.ResponseWriter, r *http.Request) {
	members, err := database.LoadMembers()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Sort members by hierarchy within each category
	sort.Slice(members, func(i, j int) bool {
		return members[i].Hierarchy < members[j].Hierarchy
	})

	// Group members by category
	managementTeam := []database.Member{}
	advisoryCouncil := []database.Member{}
	fieldMembers := []database.Member{}

	for _, member := range members {
		switch member.Category {
		case "managementteam":
			managementTeam = append(managementTeam, member)
		case "advisorycouncil":
			advisoryCouncil = append(advisoryCouncil, member)
		case "fieldmember":
			fieldMembers = append(fieldMembers, member)
		}
	}

	data := struct {
		Title           string
		ManagementTeam  []database.Member
		AdvisoryCouncil []database.Member
		FieldMembers    []database.Member
	}{
		Title:           "Our Team",
		ManagementTeam:  managementTeam,
		AdvisoryCouncil: advisoryCouncil,
		FieldMembers:    fieldMembers,
	}

	tmpl, err := template.ParseFiles(
		filepath.Join("public", "our-team.html"),
		filepath.Join("public", "header.html"),
		filepath.Join("public", "footer.html"),
		filepath.Join("public", "features.html"),
		
	)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl.ExecuteTemplate(w, "our-team.html", data)
}