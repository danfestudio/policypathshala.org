package public

import (
	"net/http"
)

func PolicyBriefsHandler(w http.ResponseWriter, r *http.Request) {
	templates(w, "policy-briefs.html", nil)
}