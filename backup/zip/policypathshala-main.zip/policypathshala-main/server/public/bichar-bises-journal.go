package public

import (
	"net/http"
)

func BicharBisesJournalHandler(w http.ResponseWriter, r *http.Request) {
	templates(w, "bichar-bises-journal.html", nil)
}