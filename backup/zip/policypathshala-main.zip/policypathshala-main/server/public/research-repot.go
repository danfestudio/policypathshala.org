package public

import (
	"net/http"
)

func ResearchReportHandler(w http.ResponseWriter, r *http.Request) {
	templates(w, "research-report.html", nil)
}