package public

import (
	"html/template"
	"net/http"
	"path/filepath"
)

// templates parses and executes the given templates.
func templates(w http.ResponseWriter, tmpl string, data interface{}) {
	// Define the template files to parse
	tmplPath := filepath.Join("public", tmpl)
	headerPath := filepath.Join("public", "header.html")
	footerPath := filepath.Join("public", "footer.html")
	featurePath := filepath.Join("public", "features.html")
	

	// Parse the templates
	t, err := template.ParseFiles(headerPath, footerPath, featurePath, tmplPath)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Execute the template
	err = t.ExecuteTemplate(w, filepath.Base(tmpl), data)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
	}
}