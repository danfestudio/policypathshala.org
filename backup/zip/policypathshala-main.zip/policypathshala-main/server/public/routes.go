package public

import (
	"net/http"
)

func Routes() {
	http.HandleFunc("/", PublicIndexHandler)

	http.HandleFunc("/about", AboutHandler)

	http.HandleFunc("/our-team", OurTeamHandler)

	http.HandleFunc("/activities", PublicActivitiesHandler)
	
	http.HandleFunc("/policy-dialogues", PublicPolicyDialogueHandler)

	http.HandleFunc("/bichar-bises-journal", BicharBisesJournalHandler)
	http.HandleFunc("/policy-briefs", PolicyBriefsHandler)
	http.HandleFunc("/research-report", ResearchReportHandler)

	http.HandleFunc("/news-media", NewsandMediaHandler)

	http.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("public/static"))))
}
