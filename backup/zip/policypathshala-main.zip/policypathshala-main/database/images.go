package database

import (
	"encoding/json"
	"os"
	"time"
)

type Image struct {
	ID          int       `json:"id"`
	URL         string    `json:"url"`
	Description string    `json:"description"`
	UploadTime  time.Time `json:"upload_time"`
	Size        int       `json:"size"`
}

func LoadImages() ([]Image, error) {
	file, err := os.Open("database/images.json")
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var images []Image
	decoder := json.NewDecoder(file)
	err = decoder.Decode(&images)
	if err != nil {
		return nil, err
	}

	return images, nil
}

func SaveImages(images []Image) error {
	file, err := os.Create("database/images.json")
	if err != nil {
		return err
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	return encoder.Encode(images)
}
