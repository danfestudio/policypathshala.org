package database

import (
	"encoding/json"
	"os"
)

type Activity struct {
	ID          int    `json:"id"`
	Title       string `json:"title"`
	Description string `json:"description"`
	ImageURL    string `json:"image_url"`
	Category    string `json:"category"`
	Date        int    `json:"date"`
	Status      int    `json:"status"`
}

func LoadActivities() ([]Activity, error) {
	file, err := os.Open("database/activities.json")
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var activities []Activity
	decoder := json.NewDecoder(file)
	err = decoder.Decode(&activities)
	if err != nil {
		return nil, err
	}

	return activities, nil
}

func SaveActivities(activities []Activity) error {
	file, err := os.Create("database/activities.json")
	if err != nil {
		return err
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	return encoder.Encode(activities)
}
