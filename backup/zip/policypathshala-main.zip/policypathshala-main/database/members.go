package database

import (
	"encoding/json"
	"os"
)

type Member struct {
	ID        int    `json:"id"`
	Name      string `json:"name"`
	Username  string `json:"username"`
	Email     string `json:"email"`
	Position  string `json:"position"`
	Mobile    string `json:"mobile"`
	About     string `json:"about"`
	Category  string `json:"category"`
	Hierarchy int    `json:"hierarchy"`
	Status    int    `json:"status"`
	Facebook  string `json:"facebook"`
	Twitter   string `json:"twitter"`
	Instagram string `json:"instagram"`
	LinkedIn  string `json:"linkedin"`
	Image     string `json:"image"`
}

func LoadMembers() ([]Member, error) {
	file, err := os.Open("database/members.json")
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var members []Member
	decoder := json.NewDecoder(file)
	err = decoder.Decode(&members)
	if err != nil {
		return nil, err
	}

	return members, nil
}

func SaveMembers(members []Member) error {
	file, err := os.Create("database/members.json")
	if err != nil {
		return err
	}
	defer file.Close()

	encoder := json.NewEncoder(file)
	return encoder.Encode(members)
}